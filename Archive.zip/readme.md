Hello there, 

this is a game of rock paper scissors

to install dependency please use npm install on this project

and there after to run simply type 'node app.js' into your terminal.

to run test simply type 'npm test' into your terminal.

refactored and extended to include spock

Thank you for giving me the chance to do this assignment! Dont know if i did enough hope it is! 
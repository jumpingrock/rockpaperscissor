Hello there, 

this is a game of rock paper scissors

to install dependency please use npm install on this project

and there after to run simply use type 'node app.js' into your terminal

to refactor for lizard spock, add required if-else logic and change spock variable to true. 

Thank you for giving me the chance to do this assignment! Dont know if i did enough hope it is! 